from distutils.core import setup

setup(name="CirMatCoder",version="0.2",description="A module for coding or Circle type operation!",author="Vater Hu",py_modules=['CirMatCoder','Coder'])
